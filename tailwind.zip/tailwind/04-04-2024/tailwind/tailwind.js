$(document).ready(function(){
 $('#hamburger').click(function(){
    $('.sidebar').toggleClass('active');
    $('.overlay').toggleClass('overlay-active');
 });
  $('.cross').click(function(){
    $('.sidebar').removeClass('active');
    $('.overlay').removeClass('overlay-active');
  })
});



