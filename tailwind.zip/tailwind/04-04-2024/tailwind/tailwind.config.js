/* @type {import('tailwindcss').Config} */

module.exports = {
  content: ["./tailwind/**/*.{html,js}"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      container: {
        screens: {
          '3xl': '1600px',
        },
      },
      fontSize: {
        '32': '2rem',
        '28': '1.75rem',
      },
      colors: {
        'brown': '#b1843b',
        'lightbrown': '#796e65',
      },
      spacing: {
        '18': '4.3rem',
        '17': '4.5rem',
        '21': '1.313rem',
        '830':'52rem',
        '42': '2.625rem',
        '41': '41rem',
         '87':'87%',
      },
      width: {
        '300': '18.75rem',
        '17': '4.5rem',
        '81': '22.25rem',
      },
      fontFamily: {
        'fontAwesome':'FontAwesome',
      },
      screens: {
        'sm': {'min': '200px', 'max': '360px'},
        'md': {'min': '361px', 'max': '500px'},
        'lg': {'min': '501px', 'max': '900px'}, 
        'xl': {'min': '901px', 'max': '1200px'},
        '2xl':{'min': '1201px', 'max': '1600px'},
        '3xl':{'min': '1601px'},
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
