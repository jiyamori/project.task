/* @type {import('tailwindcss').Config} */

module.exports = {
  content: ["./tailwind/**/*.{html,js}"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      container: {
        screens: {
          '3xl': '1600px',
        },
      },
      fontSize: {
        '32': '2rem',
        '28': '1.75rem',
      },
      colors: {
        'brown': '#b1843b',
        'lightbrown': '#796e65',
      },
      spacing: {
        '18': '4.3rem',
        '17': '4.5rem',
        '21': '1.313rem',
        '830':'52rem',
        '42': '2.625rem',
      },
      width: {
        '300': '18.75rem',
        '17': '4.5rem',
      },
      fontFamily: {
        'fontAwesome':'FontAwesome',
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
